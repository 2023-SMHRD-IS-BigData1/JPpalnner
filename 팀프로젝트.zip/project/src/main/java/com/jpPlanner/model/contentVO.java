package com.jpPlanner.model;
import java.math.BigDecimal;

public class contentVO {

	private BigDecimal schedule_num;
	private BigDecimal nday;
	private String settime;
	private String cont;
	private String price;
	private String note;
	private BigDecimal row_num;
	
	
	public BigDecimal getSchedule_num() {
		return schedule_num;
	}
	public BigDecimal getNday() {
		return nday;
	}
	public String getSettime() {
		return settime;
	}
	public String getCont() {
		return cont;
	}
	public String getPrice() {
		return price;
	}
	public String getNote() {
		return note;
	}
	public BigDecimal getRow_num() {
		return row_num;
	}
	

	
}
