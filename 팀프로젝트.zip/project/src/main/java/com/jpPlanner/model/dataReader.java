package com.jpPlanner.model;

import java.util.List;

public class dataReader {
	private String s_value;
	private String e_value;
	private List<String> p_value;

	public String getS_value() {
		return s_value;
	}

	public String getE_value() {
		return e_value;
	}

	public List<String> getP_value() {
		return p_value;
	}
}
